import React, { useState }  from 'react'
import "./HLS.css"
import one from './img/6.svg'
import two from './img/7.svg'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
export default function HLS() {
const [startDate, setStartDate] = useState(new Date());
  function sub(e)
  {
    document.querySelector(".containerA").classList.add("sign-up-mode");

  }
  function sib(e)
  {
    document.querySelector(".containerA").classList.remove("sign-up-mode");

  }

  // todo : complete the login and signup function
  function login () {

  }

  function signup() {

  }
  return (
    <div className="containerA">
      <div className="forms-containerA">
        <div className="signin-signup">
          <form action="http://localhost:3001/login/hospital" type="POST" className="sign-in-form">
            <h2 className="title">Hospital Sign in</h2>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input type="text" name="name" placeholder="Hospital Name" />
            </div>
            <div className="input-field">
              <i className="fas fa-lock"></i>
              <input name="password" type="password" placeholder="Password" />
            </div>
            <input type="submit" onSubmit={login} value="Login" className="btn solid" />
          </form>
          <form action="http://localhost:3001/register/hospital" type="POST" className="sign-up-form" >
            <h2 className="title" style={{marginTop:"30px"}}>Register and Enter Your Details</h2>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input type="text" name="name" placeholder="Full Hospital Name" required/>
            </div>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input type="text" name="registration" placeholder="Hospital Registration Number" required/>
            </div>
            <div className="input-field">
              <i className="fas fa-lock"></i>
              <input type="password" name="password" placeholder="Create Password" required/>
            </div>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input type="text" name="address" placeholder="Address" required />
            </div>
            <div style={{display:'flex'}}>
            <div className="input-field" style={{width:"190px"}}>
              <i className="fas fa-lock"></i>
              <input type="text" name="city" placeholder="City" />
            </div>
            <div className="input-field" style={{width:"190px"}}>
              <i className="fas fa-lock"></i>
              <input type="text" name="pin" placeholder="PIN Code" />
            </div>
            </div>
            <input type="submit" onSubmit={signup}  className="btn" value="Sign up" />
          </form>
        </div>
      </div>

      <div className="panels-containerA">
        <div className="panel left-panel">
          <div className="content">
            <h1>Haven't Registered Yet?</h1>
            <br/>
            <h2>
              Register Now to get free and Easy access to your Medical Records
            </h2>
            <br/>
            <h1>
              Anyplace and Anytime!!
            </h1>
            <button className="btn transparent" id="sign-up-btn" onClick={(e)=>sub(e)}>
              Sign up
            </button>
          </div>
          <img src={two} className="image" alt="" style={{position:"relative",width:"60%", height:"60%",left:"-300px"}}/>
        </div>
        <div className="panel right-panel">
          <div className="content" style={{marginLeft:"13%", marginTop:"-80px"}}>
            <h1 style={{marginLeft:"15%"}} >Already Registered ?</h1>
            <img src={one} alt="sign-up-image" style={{width:"60%",height:"90%",marginLeft:"20%"}}/>
            <p style={{marginLeft:"15%", width:"100%",fontSize:'25px',marginTop:"-90px"}}>
              Click Here to Sign in and have a look at your Medical Record in a Single Place!
            </p>
            <button style={{marginLeft:"30%"}} className="btn transparent" id="sign-in-btn" onClick={(e)=>sib(e)}>
              Sign in
            </button>
          </div>
          <img src="img/register.svg" className="image" alt="" />
        </div>
      </div>
    </div>

  )
}
