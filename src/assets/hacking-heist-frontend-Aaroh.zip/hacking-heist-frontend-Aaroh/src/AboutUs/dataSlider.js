import one from './icons/1.jfif';
import to from './icons/2.jfif';
import th from './icons/3.jfif';
import fo from './icons/4.jfif';
const data =[
    
    {
        name:'Aaroh Srivastava',
        id:"1",
        src:to,
        git:'https://github.com/Aaroh1',
        din:'https://www.linkedin.com/in/aaroh-srivastava-5051a9224/'
    },
    {
        name:'Anshu Joshi',
        id:"2",
        src:fo,
        git:'https://github.com/ImAnshuJoshi',
        din:'https://www.linkedin.com/in/anshu-joshi-9080b6223/'
    },
    {
        name:'Debajyoti Dhar',
        id:"3",
        src:th,
        git:'https://github.com/Debajyoti111',
        din:'https://www.linkedin.com/in/debajyoti-dhar-17a81021a/'
    },
     {
       name:'Sudip Banerjee',
         id:"4",
         src:one,
         git:'https://github.com/metal-oopa',
         din:'https://www.linkedin.com/in/sudip-banerjee-300b691bb/'
     }
]
export default data;