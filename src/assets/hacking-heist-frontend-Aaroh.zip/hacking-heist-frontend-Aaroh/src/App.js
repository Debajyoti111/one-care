import './App.css';
import HLS from './HLS' ;
import LS from './LS';
import Aboutsar from './AboutUs/about';
import PatientSearchPage from './PatientSearchPage';
function App() {
  return (
    <div className="App">
    {/* <LandingPage/> */}
       {/* <HLS/>  */}
     {/* <LS/> */}
     {/* <PatientSearchPage/>  */}
     <Aboutsar/>
    </div>
  );
}

export default App;
